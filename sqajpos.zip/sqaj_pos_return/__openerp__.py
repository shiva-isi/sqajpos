# -*- coding: utf-8 -*-

{
    'name': "SQAJ POS Return",
    'summary': "Customise POS for Product Return",
    'description': """
        This module for Product Return.
    """,
    'author': "iSquare Informatics",
    'category': 'Point Of Sale',
    'version': '1.0',
    'depends': ['sqaj_pos'],
    'data': [
        'views/views.xml',
    ],
    'qweb': [
        'static/src/xml/pos.xml',
    ],
    'installable': True,
    'application': True,
}
