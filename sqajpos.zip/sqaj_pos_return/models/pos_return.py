# -*- coding: utf-8 -*-

import time

from openerp import api, models, fields
from openerp.tools.translate import _
from openerp.exceptions import UserError
import datetime

class PosOrder(models.Model):
    _inherit = "pos.order"

    @api.multi
    def _is_returned(self):
        for order in self:
            order.is_returned = self.search([('parent_id', '=', order.id)]).id and True

    parent_id = fields.Many2one('pos.order', 'Order', readonly=True)
    is_returned = fields.Boolean('Is Retuened?', compute=_is_returned, help="Check Order already returned or not")
    is_return_order = fields.Boolean('Return Order', default=False, readonly=True)
    pos_return_reason = fields.Selection([
            ('cc_fr', 'Retail Sales Return/Customer Complaint/Fish Resalable'),
            ('cc_fnr', 'Retail Sales Return/Customer Complaint/Fish Non Resalable'),
            ('cc_frd', 'Retail Sales Return/Customer Complaint/Fish Resalable As Diffrent Item'),
            ('ci_fnr', 'Retail Sales Return/Cutting Issue/Fish Not Resalable'),
            ('ci_frd', 'Retail Sales Return/Cutting Issue/Fish Resalable As Diffrent Item'),
        ], 'POS Return Reason')
    product_qty = fields.Float('New Product Qty')
    product_to_id = fields.Many2one('product.product', 'New Product')
    date_order  =  fields.Datetime('Order Date', readonly=False, select=True)
    partner_id = fields.Many2one('res.partner', 'Customer', change_default=True, select=1, states={'draft': [('readonly', False)], 'paid': [('readonly', False)]}, required=True)
    
    @api.multi
    def refund(self):
        """Create a copy of order  for refund order"""
        clone_order_list = self.env['pos.order']
        for order in self:
            current_sessions = self.env['pos.session'].search([
                ('state', '!=', 'closed'),
                ('user_id', '=', self.env.uid)])
            if not current_sessions:
                raise UserError(_('To return product(s), you need to open a session that will be used to register the refund.'))

            clone_order = order.copy({
                'session_id': current_sessions[0].id,
                'date_order': time.strftime('%Y-%m-%d %H:%M:%S'),
                'parent_id': order.id,
                'location_id': current_sessions[0].config_id.stock_location_id.id,
            })
            clone_order_list += clone_order

        for clone in clone_order_list:
            for order_line in clone.lines:
                order_line.qty = -order_line.qty
        clone_order_list.is_return_order = True

        abs = {
            'name': _('Return Products'),
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'pos.order',
            'res_id': clone_order_list[0].id,
            'view_id': False,
            'context': self.env.context,
            'type': 'ir.actions.act_window',
            'target': 'current',
        }
        return abs

    def create_picking(self, cr, uid, ids, context=None):
        """Create a picking for each order and validate it."""
        picking_obj = self.pool.get('stock.picking')
        partner_obj = self.pool.get('res.partner')
        move_obj = self.pool.get('stock.move')

        for order in self.browse(cr, uid, ids, context=context):
            if all(t == 'service' for t in order.lines.mapped('product_id.type')):
                continue
            addr = order.partner_id and partner_obj.address_get(cr, uid, [order.partner_id.id], ['delivery']) or {}
            picking_type = order.picking_type_id
            picking_id = False
            location_id = order.location_id.id
            if order.partner_id:
                destination_id = order.partner_id.property_stock_customer.id
            else:
                if (not picking_type) or (not picking_type.default_location_dest_id):
                    customerloc, supplierloc = self.pool['stock.warehouse']._get_partner_locations(cr, uid, [], context=context)
                    destination_id = customerloc.id
                else:
                    destination_id = picking_type.default_location_dest_id.id

            #All qties negative => Create negative
            if picking_type:
                pos_qty = all([x.qty >= 0 for x in order.lines])
                #Check negative quantities
                picking_id = picking_obj.create(cr, uid, {
                    'origin': order.name,
                    'partner_id': addr.get('delivery',False),
                    'date_done' : order.date_order,
                    'picking_type_id': picking_type.id,
                    'company_id': order.company_id.id,
                    'move_type': 'direct',
                    'note': order.note or "",
                    'location_id': location_id if pos_qty else destination_id,
                    'location_dest_id': destination_id if pos_qty else location_id,
                }, context=context)
                self.write(cr, uid, [order.id], {'picking_id': picking_id}, context=context)

            move_list = []
            for line in order.lines:
                if line.product_id and line.product_id.type not in ['product', 'consu']:
                    continue

                move_list.append(move_obj.create(cr, uid, {
                    'name': line.name,
                    'product_uom': line.product_id.uom_id.id,
                    'picking_id': picking_id,
                    'picking_type_id': picking_type.id, 
                    'product_id': line.product_id.id,
                    'product_uom_qty': abs(line.qty),
                    'state': 'draft',
                    'location_id': location_id if line.qty >= 0 else destination_id,
                    'location_dest_id': destination_id if line.qty >= 0 else location_id,
                }, context=context))
                
            if picking_id:
                picking_obj.action_confirm(cr, uid, [picking_id], context=context)
                picking_obj.sale_in_parts(cr, uid, [picking_id], context=context)
                picking_obj.force_assign(cr, uid, [picking_id], context=context)
                # Mark pack operations as done
                pick = picking_obj.browse(cr, uid, picking_id, context=context)
                for pack in pick.pack_operation_ids:
                    self.pool['stock.pack.operation'].write(cr, uid, [pack.id], {'qty_done': pack.product_qty}, context=context)
                picking_obj.action_done(cr, uid, [picking_id], context=context)
            elif move_list:
                move_obj.action_confirm(cr, uid, move_list, context=context)
                move_obj.force_assign(cr, uid, move_list, context=context)
                move_obj.action_done(cr, uid, move_list, context=context)
            # Scrap Move For Special case
            # Irfankhan Juneja
            if order.is_return_order:
                if order.pos_return_reason in ['cc_fnr', 'ci_fnr']:
                    loc_id = self.pool.get('stock.location').search(cr, uid, [('usage', '=', 'inventory'), ('scrap_location', '=', True)], context=context)
                    scrap_location = self.pool.get('stock.location').browse(cr, uid, loc_id, context=context)
                    if not scrap_location:
                        raise Warning(_('Virtual Scrap Location is not available!'))
                    for product_part in order.lines:
                        move_lines = {
                                'product_id': product_part.product_id.id,
                                'product_uom_qty': -product_part.qty,
                                'name': product_part.product_id.name + ' Sales Return for Non Resalable',
                                'product_uom': product_part.product_id.uom_id.id,
                                'location_id': order.location_id.id,
                                'location_dest_id': scrap_location.id,
                        }
                        stock_id = self.pool.get('stock.move').create(cr, uid, move_lines, context=context)    
                        stock_rec = self.pool.get('stock.move').browse(cr, uid, [stock_id], context=context)
                        stock_rec.action_done()
                if order.pos_return_reason in ['cc_frd', 'ci_frd']:
                    loc_id = self.pool.get('stock.location').search(cr, uid, [('usage', '=', 'production')], context=context)
                    production_location = self.pool.get('stock.location').browse(cr, uid, loc_id, context=context)
                    if not production_location:
                        raise Warning(_('Please configure scrap Production location for Product Conversion'))
                    for product_part in order.lines:
                        move_line = {
                            'product_id': product_part.product_id.id,
                            'product_uom_qty': -product_part.qty,
                            'name': product_part.product_id.name +  'Use as Diffrent Receivale (Sales Return) Transfer',
                            'product_uom': product_part.product_id.uom_id.id,
                            'location_id': order.location_id.id,
                            'location_dest_id': production_location[0].id,
                        }
                        stock_id = self.pool.get('stock.move').create(cr, uid, move_line, context=context)    
                        stock_rec = self.pool.get('stock.move').browse(cr, uid, [stock_id], context=context)
                        stock_rec.action_done()
                        value = 0.0
                        for quant in stock_rec.quant_ids:
                            value += quant.inventory_value
                        cost = (value / (-product_part.qty))
                        move_line = {
                            'product_id': order.product_to_id.id,
                            'product_uom_qty': order.product_qty,
                            'name': order.product_to_id.name + 'Use as Diffrent Receivale (Sales Return) Transfer',
                            'product_uom': order.product_to_id.uom_id.id,
                            'location_id': production_location[0].id,
                            'location_dest_id': order.location_id.id,
                            'adjustment_cost': cost,
                        }
                        stock_id = self.pool.get('stock.move').create(cr, uid, move_line, context=context)    
                        stock_rec = self.pool.get('stock.move').browse(cr, uid, [stock_id], context=context)
                        stock_rec.action_done()
                        new_price = 0.0
                        qty = 0.0
                        value = 0.0
                        quant_ids = self.pool.get('stock.quant').search(cr, uid, [('product_id', '=', order.product_to_id.id), ('location_id', '=', order.location_id.id)], context=context)
                        quants = self.pool.get('stock.quant').browse(cr, uid, quant_ids, context=context)
                        for quant in quants:
                            if quant.id not in stock_rec.quant_ids.ids:
                                qty += quant.qty
                                value += quant.inventory_value
                        new_price = ((value + (cost * order.product_qty)) / (qty + order.product_qty))
                        if new_price != order.product_to_id.standard_price:
                            order.product_to_id.do_change_standard_price(new_price)
        return True

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    @api.multi
    def sale_in_parts(self):
        for picking in self:
            for move in picking.move_lines:
                if move.product_id.sub_product:
                    # Stock Available
                    if picking.state == 'assigned':
                       continue
                    # Stock Does't available
                    if picking.state == 'confirmed':
                        product_part_line = self.env['product.parts'].search([('part_product_id', '=', move.product_id.id)], limit=1)
                        if not product_part_line:
                            raise Warning(_('Product is not Configure with main Product!'))
                        main_product = self.env['product.product'].search([('product_tmpl_id', '=', product_part_line.product_id.id)], limit=1)
                        if main_product:
                            production_location = self.env['stock.location'].search([('usage', '=', 'production')], limit=1)
                            if not production_location:
                                raise Warning(_('Please configure scrap Production location'))
                            total_main = ((move.product_uom_qty * 100)/product_part_line.percentage)
                            move_lines = {
                                'product_id': main_product.id,
                                'product_uom_qty': total_main,
                                'name': move.product_id.name + 'Selling In Parts Virtual Move OUT',
                                'product_uom': move.product_id.uom_id.id,
                                'location_id': picking.location_id.id,
                                'location_dest_id': production_location.id,
                            }
                            stock_id  = self.env['stock.move'].create(move_lines)
                            stock_id.action_done()
                            value = 0.0
                            for quant in stock_id.quant_ids:
                                value += quant.inventory_value
                            cost = (value / total_main)
                            for product_part in main_product.product_parts_ids:
                                move_lines = {
                                        'product_id': product_part.part_product_id.id,
                                        'product_uom_qty': ((total_main * product_part.percentage)/ 100),
                                        'name': product_part.product_id.name + 'Selling In Parts Virtual Move IN',
                                        'product_uom': product_part.product_id.uom_id.id,
                                        'location_id': production_location.id,
                                        'adjustment_cost': cost,
                                }
                                if product_part.part_product_id.wastage_product:
                                    scrap_location = self.env['stock.location'].search([('usage', '=', 'inventory'), ('scrap_location', '=', True)])
                                    if not scrap_location:
                                        raise Warning(_('Virtual Scrap Location is not available!'))
                                    move_lines.update({'location_dest_id': scrap_location.id})
                                else:
                                    move_lines.update({'location_dest_id': picking.location_id.id})
                                stock_id = self.env['stock.move'].create(move_lines)    
                                stock_id.action_done()
                                new_price = 0.0
                                qty = 0.0
                                value = 0.0
                                quants = self.env['stock.quant'].search([('product_id', '=', product_part.part_product_id.id), ('location_id', '=', stock_id.location_dest_id.id)])
                                for quant in quants:
                                    if quant.id not in stock_id.quant_ids.ids:
                                        qty += quant.qty
                                        value += quant.inventory_value
                                new_price = ((value + (cost * ((total_main * product_part.percentage)/ 100))) / (qty + ((total_main * product_part.percentage)/ 100)))
                                if new_price != product_part.part_product_id.standard_price:
                                    product_part.part_product_id.do_change_standard_price(new_price)
                            picking.action_assign()
                    if picking.state == 'partially_available':
                        product_part_line = self.env['product.parts'].search([('part_product_id', '=', move.product_id.id)], limit=1)
                        if not product_part_line:
                            raise Warning(_('Product is not Configure with main Product!'))
                        main_product = self.env['product.product'].search([('product_tmpl_id', '=', product_part_line.product_id.id)], limit=1)
                        if main_product:
                            production_location = self.env['stock.location'].search([('usage', '=', 'production')], limit=1)
                            if not production_location:
                                raise Warning(_('Please configure scrap Production location'))
                            available_qty = picking.pack_operation_product_ids.filtered(lambda p: p.product_id == move.product_id).product_qty or 0.0
                            total_main = (((move.product_uom_qty - available_qty) * 100)/product_part_line.percentage)
                            move_lines = {
                                'product_id': main_product.id,
                                'product_uom_qty': total_main,
                                'name': move.product_id.name + 'Selling In Parts Virtual Move OUT',
                                'product_uom': move.product_id.uom_id.id,
                                'location_id': picking.location_id.id,
                                'location_dest_id': production_location.id,
                            }
                            stock_id  = self.env['stock.move'].create(move_lines)
                            stock_id.action_done()
                            value = 0.0
                            for quant in stock_id.quant_ids:
                                value += quant.inventory_value
                            cost = (value / total_main)
                            for product_part in main_product.product_parts_ids:
                                move_lines = {
                                        'product_id': product_part.part_product_id.id,
                                        'product_uom_qty': ((total_main * product_part.percentage)/ 100),
                                        'name': product_part.product_id.name + 'Selling In Parts Virtual Move IN',
                                        'product_uom': product_part.product_id.uom_id.id,
                                        'location_id': production_location.id,
                                        'adjustment_cost': cost,
                                }
                                if product_part.part_product_id.wastage_product:
                                    scrap_location = self.env['stock.location'].search([('usage', '=', 'inventory'), ('scrap_location', '=', True)])
                                    if not scrap_location:
                                        raise Warning(_('Virtual Scrap Location is not available!'))
                                    move_lines.update({'location_dest_id': scrap_location.id})
                                else:
                                    move_lines.update({'location_dest_id': picking.location_id.id})
                                stock_id = self.env['stock.move'].create(move_lines)    
                                stock_id.action_done()
                                new_price = 0.0
                                qty = 0.0
                                value = 0.0
                                quants = self.env['stock.quant'].search([('product_id', '=', product_part.part_product_id.id), ('location_id', '=', stock_id.location_dest_id.id)])
                                for quant in quants:
                                    if quant.id not in stock_id.quant_ids.ids:
                                        qty += quant.qty
                                        value += quant.inventory_value
                                new_price = ((value + (cost * ((total_main * product_part.percentage)/ 100))) / (qty + ((total_main * product_part.percentage)/ 100)))
                                if new_price != product_part.part_product_id.standard_price:
                                    product_part.part_product_id.do_change_standard_price(new_price)
                            picking.do_unreserve()
                            picking.action_assign()     
from openerp.osv import fields, osv

class pos_order_line(osv.osv):
    _inherit='pos.order.line'

    def onchange_product_id(self, cr, uid, ids, pricelist, product_id, qty=0, partner_id=False, context=None):
        context = context or {}
        if not product_id:
           return {}
        if not pricelist:
           raise UserError(
               _('You have to select a pricelist in the sale form !\n' \
               'Please set one before choosing a product.'))

        price = self.pool.get('product.pricelist').price_get(cr, uid, [pricelist],
               product_id, qty or 1.0, partner_id)[pricelist]

        result = self.onchange_qty(cr, uid, ids, pricelist, product_id, 0.0, qty, price, context=context)
        result['value']['price_unit'] = price

        prod = self.pool.get('product.product').browse(cr, uid, product_id, context=context)
        result['value']['tax_ids'] = prod.taxes_id.ids
        result['value']['qty'] = -(qty)
        return result
