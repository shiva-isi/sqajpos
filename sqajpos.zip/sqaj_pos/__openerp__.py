# -*- coding: utf-8 -*-
{
    'name': "SQAJ POS",

    'summary': """
        Custom Module for SQAJ POS.""",

    'description': """
        Custom Module for SQAJ POS.
    """,

    'author': "iSquare Informatics",
    'website': "http://www.isi.ae",

    # Categories can be used to filter modules in modules listing
    'category': 'Point Of Sale',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base', 'point_of_sale', 'sqaj_master', 'zb_pos_card_payment', 'account_cancel', 'sqaj_inventory', 'sqaj_account'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/pos_security.xml',
        'views/templates.xml',
        'report/display_report_view.xml',
        'report/report_opening_coin.xml',
        'report/report_pos_receipt2.xml',
        'views/pos_view.xml',
        'views/res_users_inherited.xml',
        'report/cash_collection_report.xml',
        'report/cash_collection_report_view.xml',
        'demo/coin.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
    'qweb': ['static/src/xml/pos.xml'],
    'installable': True,
    'auto_install': False,
}
