# -*- coding: utf-8 -*-
from openerp import models, fields, api, _
import time
import datetime
from collections import OrderedDict


class ReportCashCollection(models.AbstractModel):
    _name = 'report.sqaj_pos.report_cash_collection'

    def _get_currency(self, date):
        curr = self.env['res.currency'].search([('active', '=', True), ('id', '!=', self.env.user.company_id.currency_id.id)])
        curr_dict = OrderedDict()
        payments = self.env['payment.pos.session'].search([('closing_date', '>', date + ' 00:00:00'), ('closing_date', '<', date + ' 23:59:59'), ('state', 'in', ('closing_control','closed'))])
        curr_dict.update({'sr no': 'Sr. No.'})
        curr_dict.update({'cashier id': 'CID'})
        curr_dict.update({'cashier name': 'CASHIER NAME'})
        curr_dict.update({'opening balance': 'OPENING BALANCE'})
        curr_dict.update({'theoritical balance': 'TB'})
        curr_dict.update({'collected balance': 'CB'})
        curr_dict.update({'transaction collected': 'TC'})
        curr_dict.update({'transaction system': 'TS'})
        curr_dict.update({'access shortage': 'E/S'})
        curr_dict.update({'credit card': 'CREDIT CARD'})
        curr_dict.update({'bonus': 'BONUS'})
        for i in curr:
            curr_dict.update({str(i.name.lower()): str(i.name.upper())})

        total_dict = OrderedDict()
        total_dict.update({'sr no': ''})
        total_dict.update({'cashier id': 'Total'})
        total_dict.update({'cashier name': 'Transaction'})
        total_dict.update({'opening balance': 0.00})
        total_dict.update({'theoritical balance': 0.00})
        total_dict.update({'collected balance': 0.00})
        total_dict.update({'transaction collected': 0.00})
        total_dict.update({'transaction system': 0.00})
        total_dict.update({'access shortage': 0.00})
        total_dict.update({'credit card': 0.00})
        total_dict.update({'bonus': 0.00})
        for i in curr:
            total_dict.update({str(i.name.lower()): 0.00})

        final_list = []
        for index, docs in enumerate(payments):
            main_dict = OrderedDict()
            main_dict.update({'sr no': index + 1})
            main_dict.update({'cashier id': docs.env['res.users'].search([('id', '=', docs.user_id.id)]).cashier_id})
            main_dict.update({'cashier name': docs.user_id.name})

            main_dict.update({'opening balance': round(docs.cash_register_balance_start, 2)})
            total_dict.update({'opening balance': total_dict['opening balance'] + round(docs.cash_register_balance_start, 2)})

            main_dict.update({'theoritical balance': round(docs.cash_register_balance_end, 2)})
            total_dict.update({'theoritical balance': total_dict['theoritical balance'] + round(docs.cash_register_balance_end, 2)})

            main_dict.update({'collected balance': round(docs.cash_register_balance_real_end, 2)})
            total_dict.update({'collected balance': total_dict['collected balance'] + round(docs.cash_register_balance_real_end, 2)})

            main_dict.update({'transaction collected': round(docs.cash_register_balance_real_end - docs.cash_register_balance_start, 2)})
            total_dict.update({'transaction collected': total_dict['transaction collected'] + round(docs.cash_register_balance_real_end - docs.cash_register_balance_start, 2)})

            main_dict.update({'transaction system': round(docs.cash_register_balance_end - docs.cash_register_balance_start, 2)})
            total_dict.update({'transaction system': total_dict['transaction system'] + round(docs.cash_register_balance_end - docs.cash_register_balance_start, 2)})

            main_dict.update({'access shortage': round(docs.cash_register_diffrence, 2)})
            total_dict.update({'access shortage': total_dict['access shortage'] + round(docs.cash_register_diffrence, 2)})

            main_dict.update({'credit card': 0.00})
            main_dict.update({'bonus': 0.00})

            for i in curr:
                main_dict.update({str(i.name.lower()): 0.00})
            if docs.cash_register_credit_card:
                main_dict.update({'credit card': round(main_dict['credit card'] + docs.cash_register_credit_card, 2)})
                total_dict.update({'credit card': total_dict['credit card'] + round(main_dict['credit card'], 2)})
            else:
                main_dict.update({'credit card': round(main_dict['credit card'] + 0.00, 2)})
                total_dict.update({'credit card': total_dict['credit card'] + round(main_dict['credit card'] + 0.00, 2)})

            for pi in docs.payment_ids:
                for pl in pi.payment_lines:
                    if pl.currency_id:
                        main_dict[str(pl.currency_id.name.lower())] += round(pl.amount, 2)
                        total_dict[str(pl.currency_id.name.lower())] += round(pl.amount, 2)

            if docs.cash_register_bonus:
                main_dict.update({'bonus': round(main_dict['bonus'] + docs.cash_register_bonus, 2)})
                total_dict.update({'bonus': total_dict['bonus'] + round(main_dict['bonus'] + docs.cash_register_bonus, 2)})
            else:
                main_dict.update({'bonus': round(main_dict['bonus'] + 0.00, 2)})
                total_dict.update({'bonus': total_dict['bonus'] + round(main_dict['bonus'] + 0.00, 2)})
            final_list.append(main_dict)
        total_list = []
        total_list.append(total_dict)
        return curr_dict, final_list, total_list

    @api.multi
    def render_html(self, data):
        self.model = self.env.context.get('active_model')
        docs = self.env[self.model].browse(self.env.context.get('active_id'))
        move_lines, final_list, total_list = self._get_currency(data['form']['date'])
        data['form']['date'] = datetime.datetime.strptime(data['form']['date'], '%Y-%m-%d').strftime('%d-%m-%Y')
        docargs = {
            'doc_ids': self.ids,
            'doc_model': self.model,
            'data': data['form'],
            'docs': docs,
            'move_lines': move_lines,
            'final_list': final_list,
            'total_list': total_list,
        }
        return self.env['report'].render('sqaj_pos.report_cash_collection', docargs)


class CashCollection(models.TransientModel):
    _name = "cash.collection.report"
    _description = "Cash Collection Report"

    date = fields.Date('Date', default=lambda *a: time.strftime('%Y-%m-%d'))

    def _build_contexts(self, data):
        result = {}
        result['date'] = data['form']['date'] or False
        return result

    @api.multi
    def _print_report(self, data):
        return self.env['report'].get_action(self, 'sqaj_pos.report_cash_collection', data=data)

    @api.multi
    def print_report(self):
        self.ensure_one()
        data = {}
        data['ids'] = self.env.context.get('active_ids', [])
        data['model'] = self.env.context.get('active_model', 'ir.ui.menu')
        data['form'] = self.read(['date'])[0]

        used_context = self._build_contexts(data)
        data['form']['used_context'] = dict(used_context, lang=self.env.context.get('lang', 'en_US'))
        return self._print_report(data)

