# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import datetime
from openerp import api, fields, models, _
from openerp.exceptions import Warning
from collections import OrderedDict

class DisplayPosReport(models.TransientModel):
    _name = 'display.pos.report'

    date_from = fields.Date('From Date', required=True)
    date_to = fields.Date('To Date', required=True)
    day_of_week = fields.Selection([('Monday','Monday'),('Tuesday','Tuesday'),('Wednesday','Wednesday'),('Thursday','Thursday'),('Friday','Friday'),('Saturday','Saturday'),('Sunday','Sunday')], 'Day of Week', required=True)
    
    @api.multi
    def display_graph(self):
        dates = []
        for order in self.env['pos.order'].search([('date_order', '>=', self.date_from), ('date_order', '<=', self.date_to)]):        
            date = datetime.datetime.strptime(order.date_order, '%Y-%m-%d %H:%M:%S')
            if self.day_of_week == date.strftime("%A"):
                dates.append(order.date_order)

        return {
            'name': _('Orders Analysis'),
            'type': 'ir.actions.act_window',
            'res_model': 'pos.order',
            'view_mode': 'pivot,graph',
            'view_type': 'form',
            'search_view_id': self.env.ref('point_of_sale.view_report_pos_order_search').id,
            'domain': [('date_order', 'in', dates)],
            'context': {'group_by_no_leaf':1,'group_by':[]}
        }


class ClosingCoinReport(models.AbstractModel):
    _name = 'report.sqaj_pos.report_closing_coin'

    def _get_move_lines(self, docs):
        move_result = []
        curr = self.env['res.currency'].search([('active', '=', True), ('id', '!=', self.env.user.company_id.currency_id.id)])
        curr_dict = {}
        curr_dict['credit card'] = docs.cash_register_credit_card or 0.00
        for i in curr:
            curr_dict.update({str(i.name.lower()): 0})
        for pi in docs.payment_ids:
            for pl in pi.payment_lines:
                if pl.currency_id:
                    curr_dict[str(pl.currency_id.name.lower())] += pl.amount
        curr_dict['bonus'] = docs.cash_register_bonus or 0.00
        move_result.append(curr_dict)
        return move_result

    @api.multi
    def render_html(self, data):
        self.model = self.env.context.get('active_model')
        docs = self.env[self.model].browse(self.env.context.get('active_id'))
        move_lines = self._get_move_lines(docs)
        docargs = {
            'doc_ids': self.ids,
            'doc_model': self.model,
            'docs': docs,
            'move_lines': move_lines,
        }
        return self.env['report'].render('sqaj_pos.report_closing_coin', docargs)


class ClosingCoinReport2(models.AbstractModel):
    _name = 'report.sqaj_pos.report_closing_coin2'

    def _get_move_lines(self, docs):
        move_result = []
        curr = self.env['res.currency'].search([('active', '=', True), ('id', '!=', self.env.user.company_id.currency_id.id)])
        curr_dict = OrderedDict()
        credit_card = docs.cash_register_credit_card or 0.00
        bonus = docs.cash_register_bonus or 0.00
        for i in curr:
            curr_dict.update({str(i.name.lower()): 0})
        for pi in docs.payment_ids:
            for pl in pi.payment_lines:
                if pl.currency_id:
                    curr_dict[str(pl.currency_id.name.lower())] += pl.amount
        move_result.append(curr_dict)
        return move_result, credit_card, bonus

    @api.multi
    def render_html(self, data):
        self.model = self.env.context.get('active_model')
        docs = self.env[self.model].browse(self.env.context.get('active_id'))
        move_lines, credit_card, bonus = self._get_move_lines(docs)
        docargs = {
            'doc_ids': self.ids,
            'doc_model': self.model,
            'docs': docs,
            'move_lines': move_lines,
            'credit_card': credit_card,
            'bonus': bonus,

        }
        return self.env['report'].render('sqaj_pos.report_closing_coin2', docargs)
