odoo.define('sqaj_pos.pos_client', function (require) {
"use strict";
    var screens = require('point_of_sale.screens');
    var core = require('web.core');
    var _t = core._t;
    var Model = require('web.DataModel');
    var QWeb = core.qweb;
    var gui = require('point_of_sale.gui');
    var _super_order = screens.ActionpadWidget.prototype;
    setInterval('refreshPage()', 600000);
    screens.ActionpadWidget.include({
        check_draft_order: function(){
            var self = this;
            var order = self.pos.get_order();
            if (order.get_orderlines().length === 0) {
                this.gui.show_popup('error',{
                    'title': 'Empty Order',
                    'body':  _t('There must be at least one product in your order before it can be validated'),
                });
            return;
            }
        },

        renderElement: function() {
            var self = this;
            this._super();
            this.$('.pay').unbind();

            this.$('.pay').click(function(){
                if(self.pos.get_client()) {
                    new Model("pos.order").call("check_journal",[self.pos.get_client()]).then(function (result, journal) {
                        var journal = result['journal']
                        if(result['display'] == false){
                            $('[data-id='+journal+']').addClass('oe_hidden');
                        }
                    });
                    self.gui.show_screen('payment');
                }
                else{
                   self.gui.show_screen('payment');
                }
            });
            this.$('.create-draft-order').click(function(){
                var order = self.pos.get_order();
                var total = order ? order.get_total_with_tax() : 0;
                // console.log(total);
                if (order.get_orderlines().length === 0) {
                    self.gui.show_popup('error',{
                        'title': 'Empty Order',
                        'body':  _t('There must be at least one product in your order before it can be drfted!'),
                    });
                return;
                }
                else if(total <= 0){
                    self.gui.show_popup('error',{
                        'title': 'Order Amount',
                        'body':  _t('There must be greater than zero amount in your order before it can be drafted!'),
                    });
                return;
                }
                else {
                    self.gui.show_screen('receipt');
                }
            });
        },
    });
    screens.ReceiptScreenWidget.include({
        // Barcode print
        should_close_immediately: function(){ 
            this._super(); 
            return this.click_next() 
        },
        // Diffrenciate Receipt and Draft Order
        render_receipt: function() {
            var order = this.pos.get_order();
            var barcode; 
            var barcode_val = this.pos.get_order()['name'];
            var vals = barcode_val.split('Order ')
            if (barcode_val.indexOf('Order') != -1) {
                barcode = vals[1];
            }
            if(order['paymentlines']['length'] != 0){
                this.$('.pos-receipt-container').html(QWeb.render('PosTicket',{
                    widget:this,
                    order: order,
                    receipt: order.export_for_printing(),
                    orderlines: order.get_orderlines(),
                    paymentlines: order.get_paymentlines(),
                }));
            }
            else {
                var def = $.Deferred()
                var self = this;
                this.pos.push_order(order);
                 this.$('.pos-receipt-container').html(QWeb.render('PosDraftOrder',{
                    widget:this,
                    order: order,
                    class_val: barcode,
                    barcode_val: barcode.toString(),
                    receipt: order.export_for_printing(),
                    orderlines: order.get_orderlines(),
                }));
                $("." + barcode.toString()).barcode(barcode.toString(), "code128")
                // return $.when(def).done(function(){
                //     self.print();
                //     if (self.should_close_immediately()){
                //         self.click_next();
                //     }
                    
                // })
                // var barcode; 
                // var barcode_val = this.pos.get_order()['name'] 
                // if (barcode_val.indexOf('Order') != -1) {
                //     var vals = barcode_val.split('Order '); 
                //     if (vals) { barcode = vals[1]; 
                //         $("tr#barcode1").html($("<td align='center'><div class='" + barcode + "' style='text-align:center;'/></td>")); 
                //         debugger;
                //         $("." + barcode.toString()).barcode(barcode.toString(), "code128"); 
                //     } 
                // }
                return;
            }
        },
    });
});
function refreshPage(){ 
    location.reload(); 
}

