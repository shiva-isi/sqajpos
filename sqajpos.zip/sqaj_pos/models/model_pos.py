# -*- coding: utf-8 -*-

from openerp import models, fields, api, _
from openerp.exceptions import Warning
import datetime 
import time

class Posorder(models.Model):
    _inherit = 'pos.order'

    payment_ref = fields.Many2one('pos.central.payment', 'Payment Ref.')
    cashier = fields.Char('Cashier Name', compute="_cashier_name")

    @api.one
    @api.depends('cashier')
    def _cashier_name(self):
        self.cashier = self.env.user.name
#         if self.statement_ids and self.state in ('paid','done'):
#             self.cashier = self.statement_ids[0].journal_id.name

    @api.model
    def check_journal(self, customer):
        res = {'display': False}
        if customer:
            print("customer search")
            customer_rec = self.env['res.partner'].search([('id', '=', customer['id'])])
            print("after")
            moves = self.env['account.move.line'].search([('partner_id', '=', customer_rec.id), ('journal_id', '=', customer_rec.customer_type_id.bonus_journal.id), ('account_id', '=', customer_rec.customer_type_id.customer_bonus_credit_account.id)])
            balance = 0.0
            for move in moves:
               balance += move.credit - move.debit 
            if balance > 0:
                res['display'] = True 
            journal = self.env['account.journal'].search([('code', '=', 'BJ')])
            res.update({'journal': customer_rec.customer_type_id.bonus_journal and customer_rec.customer_type_id.bonus_journal.id or journal.id})
        return res

class EnterAmount(models.Model):
    _name = 'enter.amount'

    enter_amount = fields.Char(string="Enter Amount")
    due_amt = fields.Float(string="Due Amount", readonly=True, default=lambda self: self.env['pos.central.payment'].search([('id', '=', self._context.get('active_ids'))]).due_amount)

    @api.multi
    def enter(self):
        print("from enter.amount")
        record = self.env['pos.central.payment'].search([('id', '=', self._context['active_id'])])
        print("after recorde fetch")
        journal_id = False
        if record.payment_session_id and record.payment_session_id.journal_id:
            journal_id = record.payment_session_id.journal_id.id
        else:
            raise Warning('Journal for Cash payment Does not available in Session!')
        vals = {
            'due_amount': record.due_amount,
            'amount': self.enter_amount,
            'journal_id': journal_id,
            'payment_custom_id': record.id,
            'change': record.change,
        }
        if self.enter_amount > 0:
            self.env['payment.custom.line'].create(vals)


class ExitSession(models.Model):
    _name = 'exit.session'

    @api.multi
    def exit(self):
        docs = self.env['payment.pos.session'].search([('id', 'in', self._context.get('docs'))])
        docs.state = 'closing_control'
        docs.closing_date = fields.datetime.now()
        docs.cash_register_diffrence = docs.cash_register_balance_real_end - docs.cash_register_balance_start - docs.cash_register_cash
        return {'type': 'ir.actions.act_window_close'}


class PosCetralPayment(models.Model):
    _name = 'pos.central.payment'
    _inherit = ['mail.thread']

    @api.model
    def _default_currency(self):
        journal = self.payment_session_id.journal_id
        return journal.currency_id or journal.company_id.currency_id

    name = fields.Char('Name', default='/')
    user_id = fields.Many2one('res.users', 'Cashier', default=lambda self: self.env.user)
    order_barcode = fields.Char('Order Barcode')
    order_ids = fields.Many2many('pos.order', string='Orders')
    state = fields.Selection([('draft', 'Draft'), ('paid', 'Paid')], 'Status', default='draft')
    total_amount = fields.Float('Total Amount', compute='_compute_amount')
    avail_bonus_amount = fields.Float('Available Bonus Amount', compute='_compute_bonus')
    partner_id = fields.Many2one('res.partner', 'Customer', compute='_compute_bonus')
    date = fields.Datetime('Date Payment')
    payment_session_id = fields.Many2one('payment.pos.session', 'Payment Session')
    payment_lines = fields.One2many('payment.custom.line', 'payment_custom_id', 'Payment Line')
    due_amount = fields.Float('Due Amount', compute='_compute_due')
    change = fields.Float('Change', compute='_compute_due')
    currency_id = fields.Many2one('res.currency', 'Currency', default='_default_currency')


    def run_sql(self,payment_ref):
        print("payment ref is %s"%payment_ref)
        cr=self._cr
        cr.execute("select product_id,arabic_name,name_template,qty,price_unit,discount from pos_order_line as A  INNER JOIN pos_order as B  on A.order_id=B.id INNER JOIN product_product as C on A.product_id=C.id INNER JOIN product_template as D on C.product_tmpl_id=D.id where B.payment_ref=%s"%payment_ref)
        data=cr.dictfetchall()
        return data

    @api.one
    @api.depends('payment_lines', 'total_amount')
    def _compute_due(self):
        if self.total_amount:
            due_amount = round(self.total_amount, 2) or 0.0
            change = 0.0
            if self.payment_lines:
                for line in self.payment_lines:
                    if not line.currency_id:
                        due_amount -= round(line.amount, 2)
                        change  = line.change  or 0.0
                    else:
                        due_amount -= round(line.currency_rate, 2)
                        change  = line.change  or 0.0
            if due_amount >= 0:
                self.due_amount = due_amount
            else:
                self.due_amount = 0.0
            self.change = change

    @api.multi
    def add_cash(self):
        journal_id = False
        if self.payment_session_id and self.payment_session_id.journal_id:
            journal_id = self.payment_session_id.journal_id.id
        else:
            raise Warning('Journal for Cash payment Does not available in Session!')
        if self.due_amount == 0.0:
            raise Warning('Does not require more payment method!')
        # vals = {
        #     'amount': self.due_amount,
        # }
        # self.env['enter.amount'].create(vals)
        return {
                'name': _('Enter Amount'),
                'type': 'ir.actions.act_window',
                'res_model': 'enter.amount',
                'view_mode': 'form',
                'view_type': 'form',
                'context': {'amount': self.due_amount}, 
                'views': [(False, 'form')],
                'target': "new",
            }
        # vals = {
        #     'due_amount': self.due_amount,
        #     'amount': self.due_amount,
        #     'journal_id': journal_id,
        #     'payment_custom_id': self.id,
        #     'change': self.change,
        # }
        # self.env['payment.custom.line'].create(vals)

    @api.multi
    def add_cash_usd(self):
        journal_id = False
        if self.payment_session_id and self.payment_session_id.journal_id:
            journal_id = self.payment_session_id.journal_id
        else:
            raise Warning('Journal for Cash payment Does not available in Session!')
        if self.due_amount == 0.0:
            raise Warning('Does not require more payment method!')
        if not self.currency_id:
            raise Warning('Please Select Currency!')
        journal_id = self.env['account.journal'].search([('currency_id', '=', self.currency_id.id)])
        if not journal_id:
            raise Warning('Journal for selected Currency not configured!')
        vals = {
            'due_amount': self.due_amount,
            'currency_id': self.currency_id.id,
            'journal_id': journal_id.id,
            'payment_custom_id': self.id,
            'change': self.change,
        }
        self.env['payment.custom.line'].create(vals)

    @api.multi
    def add_bonus(self):
        journal_id = False
        if self.partner_id and self.partner_id.customer_type_id.bonus_journal:
            journal_id = self.partner_id.customer_type_id.bonus_journal.id
        else:
            raise Warning('Bonus Journal not configured!')
        if self.due_amount == 0.0:
            raise Warning('Does not require more payment method!')
        vals = {
            'due_amount': self.due_amount,
            'change': self.change,
            'journal_id': journal_id,
            'payment_custom_id': self.id,
        }
        self.env['payment.custom.line'].create(vals)

    @api.multi
    def add_credit(self):
        journal_id = self.env['account.journal'].search([('card_payment', '=', True)], limit=1)
        if not journal_id:
            raise Warning('Journal for Credit payment Does not available!')
        if self.due_amount == 0.0:
            raise Warning('Does not require more payment method!')
        vals = {
            'due_amount': self.due_amount,
            'amount': self.due_amount,
            'change': self.change,
            'journal_id': journal_id.id,
            'payment_custom_id': self.id,
        }
        self.env['payment.custom.line'].create(vals)

    @api.model
    def create(self, vals):
        res = super(PosCetralPayment, self).create(vals)
        print("vals from payment creation %s"%vals)
        session_obj=self.pool.get('payment.pos.session').browse(self._cr,self._uid,vals['payment_session_id'])
        print("session obj %s"%session_obj.counter.name)
        res.name = self.env['ir.sequence'].next_by_code('pos.central.payment')
        return res

    @api.multi
    def unlink(self):
        for rec in self:
            if rec.state == 'paid':
                raise Warning(_('You can not Delete Paid Records!'))
            return super(PosCetralPayment, rec).unlink()

    @api.onchange('order_barcode')
    def add_order_via_order_barcode(self):
        if self.order_barcode:
            if self.order_barcode[:2] == '%B': 
                code_list = self.order_barcode.split("^")
                if len(code_list) >= 2:
                    temp = code_list[2]
                    temp2 = temp.split(";")
                    card_no = temp2[1].split("=")[0]
                    if len(card_no) == 16:
                        card_no = card_no[12:]
                    card_name = code_list[1].split("  ")[0]
                    journal_id = self.env['account.journal'].search([('card_payment', '=', True)], limit=1)
                    if not journal_id:
                        raise Warning('Journal for Credit payment Does not available!')
                    if self.due_amount == 0.0:
                        raise Warning('Does not require more payment method!')
                    line_list = []
                    
                    for line in self.payment_lines:
                        vals = {
                            'due_amount': line.due_amount,
                            'change': line.change,
                            'journal_id': line.journal_id.id,
                            'payment_custom_id': line.payment_custom_id.id,
                            'card_no': line.card_no,
                            'card_name': line.card_name,
                            }
                        line_list.append((0,0,vals))
                    vals = {
                        'due_amount': self.due_amount,
                        'change': self.change,
                        'amount': self.due_amount,
                        'journal_id': journal_id.id,
                        'payment_custom_id': self.id,
                        'card_no': card_no,
                        'card_name': card_name,
                    }
                    line_list.append((0,0,vals))
                    self.payment_lines = line_list
                    self.order_barcode = False
            else:
                domain = [('pos_reference', '=', unicode(str('Order ' + self.order_barcode), "utf-8")), ('state', '=', 'draft')]
                order_id = self.env['pos.order'].search(domain)
                if not order_id:
                    self.order_barcode = ''
                    raise Warning(_('Order Does Not Exist'))
                line_list = []
                if order_id:
                    if self.order_ids:
                        for record in self.order_ids:
                            if str(record.pos_reference) == str('Order ' + self.order_barcode):
                                self.order_barcode = ''
                                raise Warning(_('Order Already Added!'))
                            else:
                                ids = self.order_ids.ids
                                ids.append(order_id.id)      
                                self.order_ids = ids
                                self.order_barcode = ''
                    else:
                        self.order_ids = [order_id.id]
                        self.order_barcode = ''

    @api.one
    @api.depends('order_ids')
    def _compute_amount(self):
        if self.order_ids:
            total = 0.0
            for order in self.order_ids:
                total += order.amount_total
            self.total_amount = total

    @api.one
    @api.depends('order_ids')
    def _compute_bonus(self):
        if self.order_ids:
            partner_id = False
            for order in self.order_ids:
                if order.partner_id:
                    partner_id = order.partner_id
            balance = 0.0
            if partner_id:
                self.partner_id = partner_id.id
                moves = self.env['account.move.line'].search([('partner_id', '=', partner_id.id), ('journal_id', '=', partner_id.customer_type_id.bonus_journal.id), ('account_id', '=', partner_id.customer_type_id.customer_bonus_credit_account.id)])
                for move in moves:
                    balance += move.credit - move.debit
                used_amount = 0.0
                for order in self.env['pos.order'].search([('partner_id', '=', partner_id.id), ('state', '=', 'paid')]):
                    for statement in order.statement_ids:
                        if statement.journal_id.id == partner_id.customer_type_id.bonus_journal.id:
                            used_amount += statement.amount
                balance = balance - used_amount
            if balance > 0:
                self.avail_bonus_amount = balance
            else:
                self.avail_bonus_amount = 0.0

    @api.multi
    def action_payment(self):
        if self.state == "draft":
            if not self.order_ids:
                raise Warning(_('Orders Information is Not available!'))
            if self.due_amount > 0:
                raise Warning(_('Payment Amount is not Sufficient!'))
            for order in self.order_ids:
                if order.state != 'draft':
                    raise Warning(_("There are some paid orders. You need to delete paid order."))
            for payment in self.payment_lines:
                if not payment.currency_id:
                    amount = payment.amount - payment.change
                    for order in self.order_ids:
                        # if order.state != 'draft':
                        #     raise Warning(_("There are some paid orders. You need to delete paid order."))
                        if amount > 0 and order.state == 'draft':
                            if (order.amount_total - order.amount_paid) > amount:
                                vals = {
                                    'amount': amount,
                                    'journal': payment.journal_id.id,
                                    'payment_date': datetime.datetime.strftime(fields.date.today(), '%Y-%m-%d'),
                                    'payment_name': order.pos_reference + '-' + self.name or '',
                                    'card_name': payment.card_name,
                                    'card_no': payment.card_no 
                                }
                                order.add_payment(order.id, vals)
                                order.state = 'paid'
                                order.create_picking()
                                order.payment_ref = self.id
                                amount = 0.0
                            else:
                                vals = {
                                    'amount': order.amount_total - order.amount_paid,
                                    'journal': payment.journal_id.id,
                                    'payment_date': datetime.datetime.strftime(fields.date.today(), '%Y-%m-%d'),
                                    'payment_name': order.pos_reference + '-' + self.name, 
                                    'card_name': payment.card_name,
                                    'card_no': payment.card_no 
                                }
                                amount -= order.amount_total - order.amount_paid
                                order.add_payment(order.id, vals)
                                amount -= order.amount_total - order.amount_paid
                                order.state = 'paid'
                                order.create_picking()
                                order.payment_ref = self.id
                else:
                    actual_rate = 1 / payment.currency_id.rate
                    amount = ((payment.amount * actual_rate) - (payment.change or 0.0))
                    for order in self.order_ids:
                        if amount > 0 and order.state == 'draft':
                            if (order.amount_total - order.amount_paid) > amount:
                                vals = {
                                    'amount': amount + (payment.change or 0.0),
                                    'journal': payment.journal_id.id,
                                    'currency_id': payment.currency_id.id,
                                    'currency_rate': ((amount + (payment.change or 0.0)) / (actual_rate or 1)),
                                    'payment_date': datetime.datetime.strftime(fields.date.today(), '%Y-%m-%d'),
                                    'payment_name': order.pos_reference + '-' + self.name, 
                                    'card_name': payment.card_name,
                                    'card_no': payment.card_no 
                                }
                                order.add_payment(order.id, vals)
                                order.state = 'paid'
                                order.create_picking()
                                order.payment_ref = self.id
                                amount = 0.0
                            else:
                                vals = {
                                    'amount': order.amount_total - order.amount_paid,
                                    'journal': payment.journal_id.id,
                                    'currency_id': payment.currency_id.id,
                                    'currency_rate': ((order.amount_total - order.amount_paid) / (actual_rate or 1)),
                                    'payment_date': datetime.datetime.strftime(fields.date.today(), '%Y-%m-%d'),
                                    'payment_name': order.pos_reference + '-' + self.name, 
                                    'card_name': payment.card_name,
                                    'card_no': payment.card_no 
                                }
                                amount -= order.amount_total - order.amount_paid
                                order.add_payment(order.id, vals)
                                order.state = 'paid'
                                order.create_picking()
                                order.payment_ref = self.id
            self.state = 'paid'
            self.date = fields.datetime.now()
            # return self.print_report2()
            # return self.payment_session_id.payment_process()

    @api.multi
    def _print_pos_order(self, data):
        return self.env['report'].get_action(self, 'sqaj_pos.report_order2', data=data)

    @api.multi
    def print_report(self):
        data = {}
        return self._print_pos_order(data)

    @api.multi
    def _print_pos_order2(self, data):
        return self.env['report'].get_action(self, 'sqaj_pos.report_receipt2', data=data)

    @api.multi
    def print_report2(self):
        data = {}
        return self._print_pos_order2(data)

    @api.constrains('payment_lines')
    def check_bonus_and_credit(self):
        # Check Change
        for rec in self:
            if rec.payment_lines:
                for payment in rec.payment_lines:
                    if payment.journal_id.name == 'Credit Journal':
                        if payment.change > 0:
                            raise Warning('Could not Allow Change amount in Credit Card Payment!')
                    if rec.partner_id:
                        if payment.journal_id == rec.partner_id.customer_type_id.bonus_journal:
                            if payment.change > 0:
                                raise Warning('Could not Allow Change amount in Bonus Payment!')
                # Check Bonus Sufficient
                if rec.partner_id:
                    total_bonus = 0.0
                    for payment in rec.payment_lines:
                        if payment.journal_id == rec.partner_id.customer_type_id.bonus_journal:
                            total_bonus += payment.amount
                    if total_bonus > rec.avail_bonus_amount:
                        raise Warning('Could not Allow More than Bonus Amount!')

class PaymentLineCustom(models.Model):
    _name = 'payment.custom.line'

    journal_id = fields.Many2one('account.journal', 'Method')
    amount = fields.Float('Tendered')
    payment_custom_id = fields.Many2one('pos.central.payment', 'Payment')
    due_amount = fields.Float('Due')
    change = fields.Float('Change', compute='compute_change')
    card_no = fields.Char(string="Card No.", size=32)
    card_name = fields.Char(string="Cardholder Name.", size=256)
    check_credit = fields.Boolean('Check Credit')
    currency_id = fields.Many2one('res.currency', string='Account Currency')
    currency_rate = fields.Float(compute='compute_change')

    @api.one
    @api.depends('amount')
    def compute_change(self):
        if self.payment_custom_id:
            if (self.amount - self.due_amount) > 0:
                self.change = self.amount - self.due_amount
            if self.journal_id.card_payment:
                if self.change > 0:
                    raise Warning(_('Could not Allow Change amount in Credit Card Payment!'))
                self.check_credit = True
            if self.payment_custom_id.partner_id:
                if self.journal_id == self.payment_custom_id.partner_id.customer_type_id.bonus_journal:
                    if self.change > 0:
                        raise Warning(_('Could not Allow Change amount in Credit Card Payment!'))
                total_bonus = 0.0
                for payment in self.payment_custom_id.payment_lines:
                    if payment.journal_id == self.payment_custom_id.partner_id.customer_type_id.bonus_journal:
                        total_bonus += payment.amount
                    if total_bonus > self.payment_custom_id.avail_bonus_amount:
                        raise Warning('Could not Allow More than Bonus Amount!')
            if self.currency_id:
                actual_rate = 1 / self.currency_id.rate
                self.currency_rate = actual_rate * self.amount
                if (self.currency_rate - self.due_amount) > 0:
                    self.change = self.currency_rate - self.due_amount

class CoinMaster(models.Model):
    _name = 'coin.master'

    value = fields.Float('Value')

class PaymentSession(models.Model):
    _name = 'payment.pos.session'
    _inherit = ['mail.thread']

    name = fields.Char('Name', default='/')
    user_id = fields.Many2one('res.users', 'Cashier', default=lambda self: self.env.user)
    journal_id = fields.Many2one('account.journal', 'Cashier Journal', domain=[('type', '=', 'cash')], compute='_get_journal')
    state = fields.Selection([('opening_control', 'Opening Control'), ('confirm', 'Confirm'), ('opened', 'In Progress'), ('closing_control', 'Closing Control'), ('closed', 'Closed')], 'Status', default='opening_control')
    opening_date = fields.Datetime('Opening Date')
    closing_date = fields.Datetime('Closing Date')
    cash_register_balance_start = fields.Float('Opening Balance')
    cash_register_transcation = fields.Float('+Transaction', compute='_transaction_amount')
    cash_register_bonus = fields.Float('+Bonus Transaction', compute='_transaction_amount')
    cash_register_cash = fields.Float('+Cash Transaction', compute='_transaction_amount')
    cash_register_credit_card = fields.Float('+Credit Card Transaction', compute='_transaction_amount')
    cash_register_balance_end = fields.Float('Closing Balance', compute='_transaction_amount')
    cash_register_balance_real_end = fields.Float('Real Closing Balance', compute='_calculate_real_balance')
    cash_register_diffrence = fields.Float('Diffrence', compute='_transaction_amount')
    payment_ids = fields.One2many('pos.central.payment', 'payment_session_id', 'Payments Summary')
    opening_coin_ids = fields.One2many('opening.coin.info', 'pos_pay_opening_id', 'Opening Coin Information')
    closing_coin_ids = fields.One2many('closing.coin.info', 'pos_pay_closing_id', 'Closing Coin Information')
    total_total = fields.Float('Total Transaction', compute='_transaction_amount')

    @api.one
    @api.depends('closing_coin_ids')
    def _calculate_real_balance(self):
        if self.closing_coin_ids:
            total = 0.0
            for closing in self.closing_coin_ids:
                total += closing.subtotal_closing
            self.cash_register_balance_real_end = total

    @api.multi
    def _print_opening_report(self, data):
        return self.env['report'].get_action(self, 'sqaj_pos.report_opening_coin', data=data)

    @api.multi
    def coin_report(self):
        if self.opening_coin_ids:
            total = 0.0
            for line in self.opening_coin_ids:
                total += line.subtotal_opening or 0.0
            if total != round(self.cash_register_balance_start, 2):
                raise Warning(_('Coin does not match with opening Balance!'))
        data = {}
        if self.state == "confirm":
            self.write({'state': "opened"})
        return self._print_opening_report(data)

    @api.multi
    def _print_closing_report(self, data):
        return self.env['report'].get_action(self, 'sqaj_pos.report_closing_coin', data=data)

    @api.multi
    def closing_coin_report(self):
        data = {}
        return self._print_closing_report(data)

    @api.multi
    def _print_closing_report2(self, data):
        return self.env['report'].get_action(self, 'sqaj_pos.report_closing_coin2', data=data)

    @api.multi
    def closing_coin_report2(self):
        data = {}
        return self._print_closing_report2(data)

    @api.multi
    def unlink(self):
        for rec in self:
            if rec.state != 'opening_control':
                raise Warning(_('You can not Delete this Session because its not in a draft state!'))
            return super(PaymentSession, rec).unlink()

    @api.depends('cash_register_balance_start', 'cash_register_transcation', 'cash_register_balance_end', 'payment_ids', 'cash_register_balance_real_end', 'cash_register_diffrence')
    def _transaction_amount(self):
        if self.payment_ids:
            total = 0.0
            credit_card = 0.0
            bonus = 0.0
            cash = 0.0
            for payment in self.payment_ids:
                if payment.state == 'paid':
                    total += payment.total_amount
                    if payment.total_amount - payment.avail_bonus_amount > 0:
                        bonus += payment.avail_bonus_amount
                    else:
                        bonus += payment.total_amount
                    for i in payment.payment_lines:
                        if not i.journal_id.currency_id and i.journal_id.type == "cash" and i.due_amount - payment.avail_bonus_amount > 0:
                            if i.due_amount > i.amount:
                                cash += i.amount - payment.avail_bonus_amount
                            else:
                                cash += i.due_amount - payment.avail_bonus_amount
                        # added for foreign curruncy payment change aed minus in total
                        if i.journal_id.currency_id and i.journal_id.type == "cash" and i.due_amount - payment.avail_bonus_amount > 0:
                            if i.change:
                                cash -= i.change
                        if i.journal_id.card_payment:
                            if i.due_amount > i.amount:
                                credit_card += i.amount
                            else:
                                credit_card += i.due_amount
            self.cash_register_cash = cash
            self.cash_register_transcation = cash
            self.cash_register_credit_card = credit_card or 0.0
            self.cash_register_bonus = bonus
            self.total_total = total
        self.cash_register_balance_end = self.cash_register_balance_start + self.cash_register_transcation or 0.0
        self.cash_register_diffrence = self.cash_register_balance_real_end - self.cash_register_balance_start - self.cash_register_cash

    @api.multi
    def start_session(self):
        if self.user_id:
            for session in self.search([('state', '!=', 'closed'), ('id', '!=', self.id)]):
                if session.user_id == self.user_id:
                    raise Warning(_('You Can Not Login with multiple Session At a time!'))
            if self.journal_id:
                self.state = 'confirm'
                for coin in self.env['coin.master'].search([]):
                    self.opening_coin_ids.create({'piece': coin.value, 'pos_pay_opening_id': self.id})
                    self.closing_coin_ids.create({'piece': coin.value, 'pos_pay_closing_id': self.id})
                account_id = self.journal_id.default_debit_account_id
                if not account_id:
                    raise Warning(_('Journal Account Not Configured!'))
                balance = 0.0
                for move in self.env['account.move.line'].search([('account_id', '=', account_id.id)]):
                    balance += move.debit - move.credit
                self.opening_date = fields.datetime.now()
                self.cash_register_balance_start = balance
            else:
                raise Warning(_('Cashier Journal Not Configured!'))
        else:
            raise Warning(_('User Information Not available!'))

    @api.multi
    def end_session(self):
        for order in self.payment_ids:
            if order.state == 'draft':
                raise Warning(_('Some Payments in Draft!'))
        opens = self.sudo().search([('state', '=', 'opened')]).ids
        if len(opens) > 1:
            pass
        else:
            if self.env['pos.order'].search([('state', '=', 'draft')]):
                raise Warning(_("You are the last cashier and you can not End session with POS Draft order."))

        return {
                'name': _(''),
                'type': 'ir.actions.act_window',
                'res_model': 'exit.session',
                'view_mode': 'form',
                'view_type': 'form',
                'context': {'docs': self.ids}, 
                'views': [(False, 'form')],
                'target': "new",
            }
        # self.state = 'closing_control'
        # self.closing_date = fields.datetime.now()
        # self.cash_register_diffrence = self.cash_register_balance_real_end - self.cash_register_balance_start - self.cash_register_cash

    @api.multi
    def validation_posting(self):
        for payment in self.payment_ids:
            for order in payment.order_ids:
                for statement in order.statement_ids:
                    if statement.statement_id.state == 'confirm': 
                        statement.statement_id.button_draft()
                    if statement.currency_id:
                        for line in statement.statement_id.line_ids:
                            line.amount = line.currency_rate
                    statement.statement_id.balance_end_real = statement.statement_id.balance_end
                    statement.statement_id.check_confirm_bank()
                order.session_id._confirm_orders()

        if self.cash_register_diffrence > 0:
            if not self.journal_id.profit_account_id:
                raise Warning(_('Please Create Profit Account!'))
            if not self.journal_id.default_debit_account_id:
                raise Warning(_('Please Create Debit Account!'))
            account_move = self.env['account.move'].create({
                'journal_id': self.journal_id.id,
                'date': fields.Date.today(),
                'line_ids': [
                (0, 0, {
                    'journal_id': self.journal_id.id,
                    'account_id': self.journal_id.profit_account_id.id,
                    'name': self.name + 'Profit',
                    'amount_currency': 0.0,
                    'credit': abs(self.cash_register_diffrence)}),
                (0, 0, {
                    'journal_id': self.journal_id.id,
                    'account_id': self.journal_id.default_debit_account_id.id,
                    'name': self.name + 'Profit',
                    'amount_currency': 0.0,
                    'debit': abs(self.cash_register_diffrence)}),
            ]})
            account_move.post()
        if self.cash_register_diffrence < 0 and self.cash_register_diffrence > -5:
            if not self.journal_id.loss_account_id:
                raise Warning(_('Please Create Loss Account!'))
            if not self.journal_id.default_credit_account_id:
                raise Warning(_('Please Create Credit Account!'))
            account_move = self.env['account.move'].create({
                'journal_id': self.journal_id.id,
                'date': fields.Date.today(),
                'line_ids': [
                (0, 0, {
                    'journal_id': self.journal_id.id,
                    'account_id': self.journal_id.loss_account_id.id,
                    'name': self.name + 'Loss',
                    'amount_currency': 0.0,
                    'debit': abs(self.cash_register_diffrence)}),
                (0, 0, {
                    'journal_id': self.journal_id.id,
                    'account_id': self.journal_id.default_credit_account_id.id,
                    'name': self.name + 'Loss',
                    'amount_currency': 0.0,
                    'credit': abs(self.cash_register_diffrence)}),
            ]})
            account_move.post()
        if self.cash_register_diffrence < -5:
            if not self.env.user.company_id.employee_shortage_deduction_account_id:
                raise Warning(_('Please Config Employee Shortage Deduction Account!'))
            account_move = self.env['account.move'].create({
                'journal_id': self.journal_id.id,
                'date': fields.Date.today(),
                'line_ids': [
                (0, 0, {
                    'journal_id': self.journal_id.id,
                    'account_id': self.journal_id.default_debit_account_id.id,
                    'name': self.name + 'Employee Deducted',
                    'amount_currency': 0.0,
                    'credit': abs(self.cash_register_diffrence)}),
                (0, 0, {
                    'journal_id': self.journal_id.id,
                    'account_id': self.env.user.company_id.employee_shortage_deduction_account_id.id,
                    'name': self.name + 'Employee Deduction',
                    'amount_currency': 0.0,
                    'debit': abs(self.cash_register_diffrence)}),
            ]})
            account_move.post()
        self.state = 'closed'

    @api.model
    def create(self, vals):
        res = super(PaymentSession, self).create(vals)
        res.name = self.env['ir.sequence'].next_by_code('pos.session.payment')
        return res

    @api.one
    @api.depends('user_id')
    def _get_journal(self):
        if self.user_id:
            journal = self.env['account.journal'].search([('user_id', '=', self.user_id.id), ('type', '=', 'cash')], limit=1)
            if journal:
                self.journal_id = journal.id

    @api.multi
    def payment_process(self):
        if self.opening_coin_ids:
            total = 0.0
            for line in self.opening_coin_ids:
                total += line.subtotal_opening or 0.0
            if total == round(self.cash_register_balance_start, 2):
                return {
                    'type': 'ir.actions.act_window',
                    'res_model': 'pos.central.payment',
                    'view_mode': 'tree,form',
                    'view_type': 'form',
                    'context': {'default_user_id': self.user_id.id, 'default_payment_session_id': self.id}, 
                    'views': [(False, 'form')],
                }
            else:
                raise Warning(_('Coin does not match with opening Balance!'))

class OpeningCoinInformation(models.Model):
    _name = 'opening.coin.info'

    piece = fields.Float('Unit of Currency')
    opening_number = fields.Integer('Number of Units')
    subtotal_opening = fields.Float('Subtotal', compute='_calculate_subtotal')
    pos_pay_opening_id = fields.Many2one('payment.pos.session', 'Payment Session')

    @api.one
    @api.depends('piece', 'opening_number')
    def _calculate_subtotal(self):
        if self.piece and self.opening_number:
            self.subtotal_opening = self.opening_number * self.piece

class ClosingCoinInformation(models.Model):
    _name = 'closing.coin.info'

    piece = fields.Float('Unit of Currency')
    closing_number = fields.Integer('Number of Units')
    subtotal_closing = fields.Float('Subtotal', compute='_calculate_subtotal')
    pos_pay_closing_id = fields.Many2one('payment.pos.session', 'Payment Session')

    @api.one
    @api.depends('piece', 'closing_number')
    def _calculate_subtotal(self):
        if self.piece and self.closing_number:
            self.subtotal_closing = self.closing_number * self.piece

class AccountJournal(models.Model):
    _inherit = 'account.journal'

    user_id = fields.Many2one('res.users', 'Cashier')

class POSSession(models.Model):
    _inherit = 'pos.session'

    def wkf_action_close(self, cr, uid, ids, context=None):
        # Close CashBox
        local_context = dict(context)
        self.write(cr, uid, ids, {'state' : 'closed', 'stop_at' : time.strftime('%Y-%m-%d %H:%M:%S')}, context=local_context)
        obj = self.pool.get('ir.model.data').get_object_reference(cr, uid, 'point_of_sale', 'menu_point_root')[1]
        return {
            'type' : 'ir.actions.client',
            'name' : 'Point of Sale Menu',
            'tag' : 'reload',
            'params' : {'menu_id': obj},
        }


class POSOrder(models.AbstractModel):
    _name = 'report.sqaj_pos.report_order2'

    @api.multi
    def render_html(self, data):
        self.model = "pos.central.payment"
        docs = self.env[self.model].browse(self.env.context.get('active_ids'))
        docargs = {
            'doc_ids': self.env.context['active_id'],
            'doc_model': self.model,
            'docs': docs,
        }
        return self.env['report'].render('sqaj_pos.report_order2', docargs)


class POSReceipt(models.AbstractModel):
    _name = 'report.sqaj_pos.report_receipt2'

    @api.multi
    def render_html(self, data):
        docs = self.env["pos.central.payment"].browse(self.env.context.get('active_ids'))
        docargs = {
            'doc_ids': self.env.context['active_id'],
            'doc_model': "pos.central.payment",
            'docs': docs,
        }
        return self.env['report'].render('sqaj_pos.report_receipt2', docargs)


class OpeningCoinReport(models.AbstractModel):
    _name = 'report.sqaj_pos.report_opening_coin'

    @api.multi
    def render_html(self, data):
        docs = self.env["payment.pos.session"].browse(self.env.context.get('active_ids'))
        docargs = {
            'doc_ids': self.env.context['active_id'],
            'doc_model': "payment.pos.session",
            'docs': docs,
        }
        return self.env['report'].render('sqaj_pos.report_opening_coin', docargs)
