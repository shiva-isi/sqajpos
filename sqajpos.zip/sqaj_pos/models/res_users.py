# -*- coding: utf-8 -*-
from openerp import models, fields, api, _

class ResUsers(models.Model):
    _inherit = 'res.users'

    cashier_id = fields.Char(string='Cashier Id')
